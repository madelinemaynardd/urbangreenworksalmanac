# Putting this on GitHub → madelinemaynardd/urbangreenworksalmanac

Everything here is already committed to a local git repository (branch `main`,
remote `origin` already set to your repo). It just needs to be pushed from a
machine that can reach github.com — this build environment is blocked from
github.com by policy, so the last step happens on your side. Pick whichever
option is easiest.

---

## Option A — Upload in the browser (no git needed, easiest)

1. Go to **https://github.com/madelinemaynardd/urbangreenworksalmanac**
2. Click **Add file → Upload files**.
3. Open the extracted **AgriGrant Dashboard** folder on your computer, select
   everything inside it (the files *and* the `Grant Resources` and `resources`
   folders), and drag them into the upload box. GitHub keeps the folder
   structure. *(You can skip the `.git` folder if you see it.)*
4. Add a commit message like "AgriGrant Dashboard — new version" and click
   **Commit changes**.

That's it — the code and README render on the repo page for anyone you share
the link with.

---

## Option B — Push with git (keeps full history in one command)

You have the whole repo already committed. On your computer, open a terminal
**inside the extracted `AgriGrant Dashboard` folder** and run:

```bash
git push -u origin main
```

If it says the remote isn't set, run this first:

```bash
git remote add origin https://github.com/madelinemaynardd/urbangreenworksalmanac.git
git branch -M main
git push -u origin main
```

You'll be asked to sign in to GitHub (browser or a Personal Access Token) the
first time.

---

## Option C — From the git bundle (if you didn't keep the `.git` folder)

I also generated `urbangreenworksalmanac.bundle` — a single file containing the
full repo and history. To use it:

```bash
git clone urbangreenworksalmanac.bundle urbangreenworksalmanac
cd urbangreenworksalmanac
git remote set-url origin https://github.com/madelinemaynardd/urbangreenworksalmanac.git
git push -u origin main
```

---

### Note on the live dashboard
GitHub will show and let people review all the **code and documents**. The
dashboard's live, interactive view needs its small Python backend running
(`python3 server.py`), so it isn't served by GitHub itself — a reviewer clones
the repo and runs it locally, exactly as in the README. If you'd like a
click-to-view web version too, tell me and I can build a self-contained
demo page.
