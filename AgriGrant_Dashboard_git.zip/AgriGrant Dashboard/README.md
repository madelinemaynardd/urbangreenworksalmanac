# AgriGrant Dashboard
### Cerasee Farm & Urban GreenWorks — Liberty City
*Where food is grown as practice, not just product.*

An interactive data dashboard for a nonprofit small farm and urban green-works
operation. It tracks community benefit, crop yields, sustainability metrics,
crop economics, the CSA program, grant compliance, and project milestones —
organized into add/remove/minimize **widgets** that you can filter by category
from the sidebar. Data is editable through a built-in admin page or a REST
backend, and can be kept current automatically from **Google Sheets** on a
weekly schedule.

This build follows an **embodied-design** philosophy drawn from the farm's
*Purpose Driven Farming* framework: the human, physical, and sacred dimension of
farming is referenced throughout the dashboard's structure so the work is never
reduced to numbers alone (see "Embodied design" below).

---

## Quick start

You need **Python 3** (it ships with macOS and is a free install on Windows).
No other installation is required — the backend uses only the Python standard
library.

**macOS:** double-click `Launch AgriGrant.command`
**Windows:** double-click `Launch AgriGrant.bat`
**Any system, from a terminal:**

```bash
cd "AgriGrant Dashboard"
python3 server.py
```

Then open **http://localhost:7654/** in your browser. The admin/data page is at
**http://localhost:7654/admin.html** (or use the **⚙ Manage Data** button).

To stop the server, close the terminal window or press `Ctrl + C`.

---

## What the dashboard does

### Sidebar + categories
A left sidebar groups every widget into nine categories, each showing a live
count and its guiding principle:

| Category | What it covers |
|----------|----------------|
| 🌿 Purpose & Practice | The values framework: Three Foundations, Ten Perfections, the 13-week AgriWorks curriculum, and a rotating field reflection |
| 🤝 Community Impact | Lbs distributed, families served, volunteer hours, CSA shares |
| 🧺 CSA Program | Orders over time, share popularity, monthly sales, full order breakdown |
| 🌽 Crop Yields | Yield to date, monthly yield by crop, bed/plot status |
| 🌱 Sustainability | Carbon sequestered, water use, solar generation, soil moisture & nutrients |
| 💵 Crop Economics | Per-crop cost / revenue / profit margin, utilization |
| 📋 Grants & Budget | Grant progress, budget allocated vs. spent, milestones, deadlines |
| ✅ Project Mgmt | Task list, **milestone roadmap**, grant deadlines |
| 🗺️ Field Map | Visual bed/plot status map |

Click any category to show only those widgets, or **All Widgets** to see
everything. The **View Density → Focused** toggle gives a streamlined view with
just the key widgets in each category, so the screen isn't crowded.

### Widgets: add, remove, minimize, expand
- **＋ Add Widget** opens a catalog (grouped by category) of every available
  widget; pick any to place it on the board.
- **⤢ Expand** opens the widget in a detail view showing the **enlarged visual,
  the complete underlying data table, a link to the source Google Sheet / Excel
  it came from, and a short human reflection**. (This replaces the earlier
  expand behavior that opened a blank enlarged card.)
- The **—** button collapses a widget to just its title bar; **▢** shows it again.
- The **✕** button removes a widget from view. Nothing is lost — **Restore
  hidden widgets** in the sidebar brings any removed widget back. Your layout
  (which widgets are shown, collapsed, and in what order) is saved in the
  database and persists across restarts.

Every widget shows its **units** (on axes, table headers, and KPI values) and
carries a one-line **human anchor** tying the number back to people, labor, and
living soil.

### Embodied design
The **Purpose & Practice** category makes the farm's values structural, not
decorative: the Three Foundations (Morality/Organic, Mind-Mastery/Permaculture,
Wisdom/Regenerative), the Ten Perfections in the field, the 13-week AgriWorks
curriculum (each week pairs a farm task with a reflection prompt), and a
reflection prompt that rotates through the season. Each category carries a
guiding principle, and every widget footer connects its data to the human work
behind it. Source: `resources/purpose-driven-farming-framework.pdf`.

### CSA Program
Built from the farm's Farmhand order export
(`resources/Farmhand_CSA_orders.xlsx`, 295 orders). The CSA tab shows orders
over time, farm-share popularity, monthly sales, and a preview of the latest
orders. **Expand** any CSA widget for the full breakdown — who ordered, when,
where, and how much — plus analytics: repeat-customer rate, most-popular share
size, monthly sales, and grand total. Because the export has no price column,
**revenue is estimated from editable unit prices** you can adjust under
Manage Data → CSA.

### Milestone Roadmap
The **Project Mgmt** tab includes a phased roadmap (Near-Term, October launch,
November farm stand, and ongoing work) covering funding applications, entity
launches, the farm stand, and standing commitments. Edit it under
Manage Data → Roadmap.

### Editing data
Two ways to keep the numbers current:

1. **Manage Data page** (`admin.html`) — tabbed CRUD forms for every dataset:
   Farm & Yields, Community, Sustainability, Economics, Grants & Budget,
   Tasks & Deadlines, **Roadmap**, and **CSA** (unit prices). Add, edit, or
   delete rows directly.
2. **REST API** — the backend exposes `GET/POST/PUT/DELETE` endpoints under
   `/api/...` (e.g. `/api/tasks`, `/api/economics`, `/api/plots`) if you want to
   script updates or connect another tool.

---

## Connecting Google Sheets (weekly auto-update)

The **🔗 Google Sheets** button lets you link a Google Sheet to any of these
datasets: plots/beds, budget, monthly yield, farm inputs, community impact,
sustainability, and economics.

**To connect a sheet:**
1. In Google Sheets, choose **Share → General access → Anyone with the link →
   Viewer**, and copy the link.
2. In the dashboard, open **🔗 Google Sheets**, paste the link next to the
   dataset it should feed, enable it, and save.
3. Use **Sync now** to pull immediately, or let the built-in scheduler refresh
   it **weekly** on its own (it checks hourly and re-syncs any connected sheet
   whose data is more than 7 days old).

**Sheet format:** the first row must be column headers. The connections dialog
lists the exact column names each dataset expects (e.g. a community sheet uses
`month, lbs_dist, families, volunteer_hrs, csa_shares`). Matching is
case-insensitive. Rows are matched on their key column (e.g. `month` or `crop`)
— existing rows update, new rows are added.

---

## Works offline

Reliable internet can be spotty in the field, so the dashboard is built to keep
working without it. When online it loads the Chart.js charting library from a
CDN; when there's no connection it automatically falls back to a small bundled
renderer (`chart-mini.js`) so every chart still draws. The backend and database
are entirely local, so the dashboard itself runs with no internet at all — only
the weekly Google Sheets sync needs a connection (and only when it runs).

---

## Files

| File | Purpose |
|------|---------|
| `server.py` | Backend: local web server, SQLite database, REST API, Google Sheets sync scheduler |
| `index.html` | Main dashboard (sidebar, widgets, modals) |
| `app.js` | Frontend engine — renders widgets, charts, filters, add/remove/minimize |
| `chart-mini.js` | Offline chart fallback (used only when the CDN is unreachable) |
| `admin.html` | Manage Data page — CRUD forms for every dataset |
| `csa_seed.py` | CSA orders parsed from the Farmhand export (bundled so the server needs no Excel libraries) |
| `agrigrant.db` | SQLite database (created/seeded automatically on first run) |
| `resources/` | Source files the dashboard links to (framework PDF, CSA Excel export) |
| `Grant Resources/` | One folder per grant/funding pool — guidelines, deadlines, and (for EQIP) the NRCS practice standards |
| `Launch AgriGrant.command` / `.bat` | One-click launchers for macOS / Windows |

---

## Grant Resources folders

The **📁 Grant Resources** button (and the `Grant Resources/` folder) organizes
each grant or funding pool into its own folder with a guidelines-and-deadlines
README:

- **EQIP – USDA NRCS (Awarded)** — fully populated with the 11 Florida
  Conservation Practice Standards for the awarded practices (Cover Crop, Soil
  Carbon Amendment, No-Till, Nutrient Management, Microirrigation, High Tunnel,
  Mulching, Pumping Plant, Roof Runoff, Pest Management, Irrigation Water
  Management) plus the NRCS Regenerative Pilot Program / CEMA 216 soil-health
  client packet, and an overview README of requirements and key dates.
- USDA Urban Agriculture, Knight Foundation, City Green Fund, Florida Blue
  Community Investments, Health Foundation of South Florida, Walmart Spark Good
  Local Grants, Tesla donation, and Home Depot grant — each with a template
  README (status, cycle, deadlines, portal link, checklist) ready to fill in.

Deadlines in these folders mirror the dashboard's Milestone Roadmap and Grant
Deadlines widgets.

> The database arrives pre-seeded with realistic Cerasee Farm sample data so
> every widget has something to show on first launch. Edit or replace it through
> the Manage Data page or by connecting your Google Sheets.

---

## Resetting the data

To start from a blank/seed database, stop the server, delete `agrigrant.db`, and
start the server again — it recreates and re-seeds the file on launch.
