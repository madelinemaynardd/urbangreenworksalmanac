# EQIP — USDA NRCS Environmental Quality Incentives Program
### Status: ✅ AWARDED — Cerasee Farm

The Environmental Quality Incentives Program (EQIP) is USDA's flagship working-lands
conservation program, delivered by the Natural Resources Conservation Service (NRCS).
It provides financial and technical assistance to implement **conservation practices**
on working farms. Cerasee Farm's award is being carried out under NRCS's
**Regenerative Pilot Program**, which bundles multiple practices into a single
whole-farm regenerative conservation plan and pairs them with soil-health testing
(**CEMA 216**).

> Guidance documents lack the force and effect of law unless expressly authorized by
> statute or incorporated into a contract. This folder organizes the farm's working
> copies — always confirm current requirements with the local NRCS Service Center.

---

## What this folder contains

```
EQIP - USDA NRCS (Awarded)/
├── README.md                                          ← this file
├── NRCS Regenerative Pilot Program - CEMA 216 Client Packet.pdf
└── Conservation Practice Standards/                   ← the 11 CPS documents below
```

### The Regenerative Pilot Program (client packet)
The pilot addresses **whole-farm resource concerns** through a single regenerative
application (EQIP and CSP now share one application process). Producer requirements:

- Work with NRCS staff, partners, or a Technical Service Provider (TSP) to complete a
  **whole-farm assessment** covering all soil and water resource concerns.
- Use **at least one primary regenerative management practice** (see list below).
- Agree to **soil-health testing (CEMA 216)** in the first and last year of the
  contract — to set a baseline and record the resulting change.

### CEMA 216 — Soil Health Testing (financial assistance)
Hire a **Qualified Individual (QI)** or Technical Service Provider to run quantitative
biological, chemical, and physical soil tests via approved labs.
- **Basic package (5 indicators):** Wet Aggregate Stability, Soil Organic Carbon,
  Soil Respiration, Labile Carbon, Bioavailable Nitrogen — plus soil pH and texture.
  Advanced options: PLFA or soil enzymes.
- **Sampling:** submit **three distinct composite samples** (each from five subsamples,
  6–8 in. depth); sample at the same time of year and same locations each round.
- **Labs & handling:** use certified labs (NAPT/ANSI/ISO); biological tests (PLFA, enzymes)
  ship overnight on ice.
- **QI eligibility:** Certified Crop Advisor / Professional Agronomist; Certified or
  Associate Professional Soil Scientist; a certified TSP (practice 116 or 162); or an
  associate degree+ in ag/soil science with 2+ years' sampling experience. Others may
  collect samples under a QI's supervision.

---

## Conservation Practice Standards (CPS) in this award

Each PDF is the **Florida** CPS defining the practice's purpose, conditions, criteria,
and documentation requirements. Practices map directly to the dashboard's
sustainability and yields widgets.

| CPS | Practice | Dashboard tie-in |
|----:|----------|------------------|
| 325 | High Tunnel System | Season extension, yields |
| 329 | Residue & Tillage Management, No-Till | Soil carbon, soil health |
| 336 | Soil Carbon Amendment | Carbon sequestered (sustainability) |
| 340 | Cover Crop | Soil nutrients, off-season beds |
| 441 | Irrigation System, Microirrigation | Water used (sustainability) |
| 449 | Irrigation Water Management | Water used (sustainability) |
| 484 | Mulching | Water retention, weed suppression |
| 533 | Pumping Plant | Irrigation infrastructure |
| 558 | Roof Runoff Structure | Water capture |
| 590 | Nutrient Management | Soil nutrient (NPK) widget |
| 595 | Pest Management Conservation System | Organic/IPM practice |

---

## Key dates & obligations

| Item | When |
|------|------|
| FY2026 applications / ranking | Confirm your state's **ranking dates** with the local NRCS Service Center |
| Soil-health baseline test (CEMA 216) | **Year 1** of the contract |
| Soil-health closing test (CEMA 216) | **Final year** of the contract |
| Practice implementation | Per the schedule in your signed EQIP contract |
| Practice certification / payment | After each practice is installed and certified by NRCS |

> ⚠️ Fill in the farm's actual contract number, obligation amount, practice schedule,
> and payment dates from the signed EQIP contract once on hand.

## Checklist
- [ ] File the signed EQIP contract and payment schedule in this folder
- [ ] Confirm the QI/TSP for CEMA 216 soil testing (see client packet's TSP registry)
- [ ] Schedule Year-1 baseline soil sampling (3 composite samples)
- [ ] Log each practice's install date → certify with NRCS → record payment
- [ ] Enter carbon / water / nutrient results into the dashboard (Manage Data)

## Contacts & links
- Local NRCS Service Center (Miami-Dade): find via https://www.farmers.gov/service-center-locator
- EQIP program page: https://www.nrcs.usda.gov/programs-initiatives/eqip-environmental-quality-incentives
- Florida CPS library: https://www.nrcs.usda.gov/resources/guides-and-instructions/florida-conservation-practice-standards
