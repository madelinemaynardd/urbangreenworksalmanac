# Tesla Vehicle & EV Charger Donation

- **Status:** 🟠 Submit / follow up (near-term)
- **Cycle:** Rolling donation request.
- **Deadline(s):** Sep 2026
- **Focus:** In-kind vehicle and/or EV charger donation for farm operations.
- **Portal / link:** https://www.tesla.com/support/donation-requests

## Notes
- Connect the ask to the solar generation already tracked on the Sustainability tab.
- Prepare 501(c)(3) documentation and a specific use case (deliveries / CSA logistics).

## Deadlines
| Item | Due |
|------|-----|
| (add application / report items here) | Sep 2026 |

## Checklist
- [ ] Confirm eligibility & required documents (501(c)(3), budget, org profile)
- [ ] Draft narrative — pull metrics from the dashboard (Community / CSA / Sustainability)
- [ ] Internal review
- [ ] Submit
- [ ] Log confirmation & follow-up date here

## Files
_Drop guidelines, application drafts, budgets, and award letters for this funder in this folder._
