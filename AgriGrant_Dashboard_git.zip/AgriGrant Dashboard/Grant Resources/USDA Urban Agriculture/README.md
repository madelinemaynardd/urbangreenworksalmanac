# USDA Urban Agriculture

- **Status:** 🟢 Active reporting
- **Cycle:** Active grant — reporting obligations.
- **Deadline(s):** Mid-season report 2026-06-30 · Carbon-credit data export 2026-09-01
- **Focus:** Urban agriculture & innovative production support.
- **Portal / link:** https://www.usda.gov/topics/urban  (Office of Urban Agriculture and Innovative Production)

## Notes
- Keep mid-season financial report and carbon-credit data export on schedule (see dashboard Deadlines).
- Separate from the EQIP award — see the EQIP folder for that.

## Deadlines
| Item | Due |
|------|-----|
| (add application / report items here) | Mid-season report 2026-06-30 · Carbon-credit data export 2026-09-01 |

## Checklist
- [ ] Confirm eligibility & required documents (501(c)(3), budget, org profile)
- [ ] Draft narrative — pull metrics from the dashboard (Community / CSA / Sustainability)
- [ ] Internal review
- [ ] Submit
- [ ] Log confirmation & follow-up date here

## Files
_Drop guidelines, application drafts, budgets, and award letters for this funder in this folder._
