# Grant & Funding Resources — Cerasee Farm / Urban GreenWorks

One folder per grant or funding pool. Each holds that funder's guidelines, deadlines,
application drafts, and award letters. Drop new documents into the matching folder.

| Folder | Status | Next deadline |
|--------|--------|---------------|
| **EQIP - USDA NRCS (Awarded)** | ✅ Awarded | Year-1 soil test (CEMA 216); practice schedule |
| USDA Urban Agriculture | 🟢 Active | Mid-season report Jun 30 · Carbon export Sep 1, 2026 |
| Knight Foundation | 🟢 Active | Impact narrative Jul 15, 2026 |
| City Green Fund | 🟡 Renewal | Renewal Oct 10, 2026 |
| Florida Blue Community Investments | 🟠 To submit | Rolling — Sep 2026 target |
| Health Foundation of South Florida | 🟠 Follow up | Rolling (GOapply) |
| Walmart Spark Good Local Grants | 🟠 To submit | Both store locations — Sep 2026 |
| Tesla Vehicle & EV Charger Donation | 🟠 Submit/follow up | Rolling |
| Home Depot Grant | 🔵 Conditional | Before Nov 2026 farm-stand launch |

These deadlines mirror the **Milestone Roadmap** and **Grant Deadlines** widgets in the
dashboard (Project Mgmt tab). Update both when dates change.

> The EQIP folder is fully populated with the 11 Florida Conservation Practice Standards
> for the awarded practices plus the NRCS Regenerative Pilot Program / CEMA 216 client packet.
