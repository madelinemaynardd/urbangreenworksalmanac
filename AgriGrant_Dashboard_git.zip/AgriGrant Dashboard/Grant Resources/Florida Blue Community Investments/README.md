# Florida Blue Community Investments

- **Status:** 🟠 To submit (near-term)
- **Cycle:** Rolling application — submit when ready.
- **Deadline(s):** Sep 2026 (target)
- **Focus:** Community health & wellbeing investments in Florida.
- **Portal / link:** https://www.floridablue.com/about-us/corporate-social-responsibility

## Notes
- Frame Cerasee/UGW as food-as-health in a Liberty City food desert.
- Tie to CSA reach and pounds distributed (see dashboard Community + CSA tabs).

## Deadlines
| Item | Due |
|------|-----|
| (add application / report items here) | Sep 2026 (target) |

## Checklist
- [ ] Confirm eligibility & required documents (501(c)(3), budget, org profile)
- [ ] Draft narrative — pull metrics from the dashboard (Community / CSA / Sustainability)
- [ ] Internal review
- [ ] Submit
- [ ] Log confirmation & follow-up date here

## Files
_Drop guidelines, application drafts, budgets, and award letters for this funder in this folder._
