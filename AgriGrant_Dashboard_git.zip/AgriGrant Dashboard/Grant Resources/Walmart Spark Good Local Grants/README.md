# Walmart Spark Good Local Grants

- **Status:** 🟠 To submit — both locations (near-term)
- **Cycle:** Quarterly windows via the Spark Good / Deed portal.
- **Deadline(s):** Sep 2026 (both stores)
- **Focus:** Local community grants ($250–$5,000) from nearby Walmart/Sam's Club stores.
- **Portal / link:** https://walmart.org/how-we-give/local-community-grants

## Notes
- Submit a separate application for EACH of the two store locations.
- Must have a registered nonprofit profile with Deed; confirm eligibility dates.

## Deadlines
| Item | Due |
|------|-----|
| (add application / report items here) | Sep 2026 (both stores) |

## Checklist
- [ ] Confirm eligibility & required documents (501(c)(3), budget, org profile)
- [ ] Draft narrative — pull metrics from the dashboard (Community / CSA / Sustainability)
- [ ] Internal review
- [ ] Submit
- [ ] Log confirmation & follow-up date here

## Files
_Drop guidelines, application drafts, budgets, and award letters for this funder in this folder._
