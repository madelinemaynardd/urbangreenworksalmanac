# Home Depot Grant

- **Status:** 🔵 Conditional (Nov farm stand)
- **Cycle:** Community Impact Grants (up to $5,000), rolling.
- **Deadline(s):** Before Nov 2026 farm-stand launch
- **Focus:** Materials/tools grant; potential juice-bar build-out for the farm stand.
- **Portal / link:** https://corporate.homedepot.com/foundation  (Community Impact Grants via The Home Depot Foundation)

## Notes
- If funds materialize in time, coordinate the juice-bar structure into the farm-stand launch.
- Community Impact Grants are typically for registered nonprofits / 501(c)(3).

## Deadlines
| Item | Due |
|------|-----|
| (add application / report items here) | Before Nov 2026 farm-stand launch |

## Checklist
- [ ] Confirm eligibility & required documents (501(c)(3), budget, org profile)
- [ ] Draft narrative — pull metrics from the dashboard (Community / CSA / Sustainability)
- [ ] Internal review
- [ ] Submit
- [ ] Log confirmation & follow-up date here

## Files
_Drop guidelines, application drafts, budgets, and award letters for this funder in this folder._
