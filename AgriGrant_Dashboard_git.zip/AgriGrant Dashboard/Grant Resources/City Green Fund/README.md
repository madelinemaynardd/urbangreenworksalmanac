# City Green Fund

- **Status:** 🟡 Renewal due
- **Cycle:** Annual renewal.
- **Deadline(s):** Annual renewal application 2026-10-10
- **Focus:** Local green-space / urban greening support.
- **Portal / link:** (confirm municipal program contact)

## Notes
- Prepare the annual renewal application ahead of the Oct 10 deadline.

## Deadlines
| Item | Due |
|------|-----|
| (add application / report items here) | Annual renewal application 2026-10-10 |

## Checklist
- [ ] Confirm eligibility & required documents (501(c)(3), budget, org profile)
- [ ] Draft narrative — pull metrics from the dashboard (Community / CSA / Sustainability)
- [ ] Internal review
- [ ] Submit
- [ ] Log confirmation & follow-up date here

## Files
_Drop guidelines, application drafts, budgets, and award letters for this funder in this folder._
