# Health Foundation of South Florida

- **Status:** 🟠 Follow up (near-term)
- **Cycle:** Rolling inquiry via GOapply.
- **Deadline(s):** Sep 2026 (follow up)
- **Focus:** Health equity and community wellbeing in South Florida.
- **Portal / link:** https://hfsf.org  (apply via GOapply)

## Notes
- Follow up on the rolling letter of inquiry already submitted through GOapply.
- Attach community-impact metrics (families served, volunteer hours).

## Deadlines
| Item | Due |
|------|-----|
| (add application / report items here) | Sep 2026 (follow up) |

## Checklist
- [ ] Confirm eligibility & required documents (501(c)(3), budget, org profile)
- [ ] Draft narrative — pull metrics from the dashboard (Community / CSA / Sustainability)
- [ ] Internal review
- [ ] Submit
- [ ] Log confirmation & follow-up date here

## Files
_Drop guidelines, application drafts, budgets, and award letters for this funder in this folder._
