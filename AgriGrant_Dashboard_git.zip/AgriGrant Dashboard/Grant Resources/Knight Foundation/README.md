# Knight Foundation

- **Status:** 🟢 Active reporting
- **Cycle:** Invitation / rolling for Miami initiatives.
- **Deadline(s):** Community impact narrative 2026-07-15
- **Focus:** Community & place-based investment in Miami.
- **Portal / link:** https://knightfoundation.org

## Notes
- Deliver the community-impact narrative; draw on the Community Impact tab metrics.

## Deadlines
| Item | Due |
|------|-----|
| (add application / report items here) | Community impact narrative 2026-07-15 |

## Checklist
- [ ] Confirm eligibility & required documents (501(c)(3), budget, org profile)
- [ ] Draft narrative — pull metrics from the dashboard (Community / CSA / Sustainability)
- [ ] Internal review
- [ ] Submit
- [ ] Log confirmation & follow-up date here

## Files
_Drop guidelines, application drafts, budgets, and award letters for this funder in this folder._
